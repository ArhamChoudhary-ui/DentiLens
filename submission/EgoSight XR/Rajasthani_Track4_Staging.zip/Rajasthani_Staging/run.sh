#!/usr/bin/env bash
set -euo pipefail
if [[ "$#" -ne 2 ]]; then
  printf 'Usage: %s <video.mp4> <out.json>\n' "$0" >&2
  exit 2
fi
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
if [[ -n "${EGOSIGHT_PYTHON:-}" ]]; then
  PYTHON="$EGOSIGHT_PYTHON"
elif [[ -x "$ROOT/.venv/bin/python" ]]; then
  PYTHON="$ROOT/.venv/bin/python"
else
  PYTHON=python3.11
fi
if ! command -v "$PYTHON" >/dev/null 2>&1; then
  printf 'Install Python 3.11 and the packages in requirements.txt.\n' >&2
  exit 127
fi
exec "$PYTHON" "$ROOT/code/main.py" "$@"
